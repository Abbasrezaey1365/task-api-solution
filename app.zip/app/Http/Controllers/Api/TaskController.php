<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Repositories\TaskRepository;
use App\Services\TaskService;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function __construct(
        private readonly TaskService $service,
        private readonly TaskRepository $tasks
    ) {}

    public function index(Request $request)
    {
        $userId = (int) $request->user()->id;

        $data = $request->validate([
            'project_id' => ['required', 'integer', 'exists:projects,id'],
            'status' => ['sometimes', 'string', 'in:todo,doing,done'],
        ]);

        $filters = [];
        if (isset($data['status'])) {
            $filters['status'] = $data['status'];
        }

        $page = $this->service->list(
            userId: $userId,
            projectId: (int) $data['project_id'],
            filters: $filters,
            perPage: (int) ($request->integer('per_page') ?: 50),
        );

        return response()->json($page);
    }

    public function store(Request $request)
    {
        $userId = (int) $request->user()->id;

        $data = $request->validate([
            'project_id' => ['required', 'integer', 'exists:projects,id'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'status' => ['sometimes', 'string', 'in:todo,doing,done'],
            'due_date' => ['nullable', 'date'],

            'assignee_id' => ['nullable', 'integer', 'exists:users,id'],
            'assigned_user_id' => ['nullable', 'integer'], // NOT FK
        ]);

        $task = $this->service->create(
            projectId: (int) $data['project_id'],
            userId: $userId,
            data: $data
        );

        return response()->json($task, 201);
    }

    public function show(Request $request, Task $task)
    {
        // basic ownership check: must own the project
        $this->tasks->assertTaskVisibleToUser((int) $request->user()->id, $task->id);

        return response()->json($task);
    }

    public function update(Request $request, Task $task)
    {
        $this->tasks->assertTaskVisibleToUser((int) $request->user()->id, $task->id);

        $data = $request->validate([
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'status' => ['sometimes', 'string', 'in:todo,doing,done'],
            'due_date' => ['nullable', 'date'],

            'assignee_id' => ['nullable', 'integer', 'exists:users,id'],
            'assigned_user_id' => ['nullable', 'integer'],
        ]);

        $updated = $this->service->update(
            userId: (int) $request->user()->id,
            taskId: (int) $task->id,
            data: $data
        );

        return response()->json($updated);
    }

    public function destroy(Request $request, Task $task)
    {
        $this->tasks->assertTaskVisibleToUser((int) $request->user()->id, $task->id);

        $this->service->delete((int) $request->user()->id, (int) $task->id);

        return response()->json(['ok' => true]);
    }

    public function projectIndex(Request $request, int $project)
{
    $request->merge(['project_id' => $project]);
    return $this->index($request);
}

public function projectStore(Request $request, int $project)
{
    $request->merge(['project_id' => $project]);
    return $this->store($request);
}

}
