<?php

namespace App\Services;

use App\Repositories\TaskRepository;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Cache;

class TaskService
{
    public function __construct(private readonly TaskRepository $tasks)
    {
    }

    public function list(int $userId, int $projectId, array $filters, int $perPage = 50): LengthAwarePaginator
    {
        $versionKey = "tasks:project:{$projectId}:version";
        $version = (int) Cache::get($versionKey, 1);

        $cacheKey = "tasks:list:project:{$projectId}:user:{$userId}:v{$version}:" . md5(json_encode([
            'filters' => $filters,
            'perPage' => $perPage,
            'page' => request('page', 1),
        ]));

        return Cache::remember($cacheKey, 3600, function () use ($userId, $projectId, $filters, $perPage) {
            return $this->tasks->paginateForUserProject(
                userId: $userId,
                projectId: $projectId,
                filters: $filters,
                perPage: $perPage
            );
        });
    }

    public function bumpProjectTasksVersion(int $projectId): void
    {
        $versionKey = "tasks:project:{$projectId}:version";
        Cache::increment($versionKey);
    }

    public function create(int $projectId, int $userId, array $data)
    {
        $task = $this->tasks->create($projectId, [
            // user_id is nullable in DB (tests), but service should set it
            'user_id' => $userId,

            'assigned_user_id' => $data['assigned_user_id'] ?? ($data['assignee_id'] ?? null),
            'assignee_id' => $data['assignee_id'] ?? ($data['assigned_user_id'] ?? null),

            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'status' => $data['status'] ?? 'todo',
            'due_date' => $data['due_date'] ?? null,
        ]);

        $this->bumpProjectTasksVersion($projectId);

        return $task;
    }

    public function update(int $userId, int $taskId, array $data)
    {
        $task = $this->tasks->findForUserOrFail($userId, $taskId);

        if (array_key_exists('assignee_id', $data) || array_key_exists('assigned_user_id', $data)) {
            $new = $data['assignee_id'] ?? $data['assigned_user_id'] ?? null;
            $task->assignee_id = $new;
            $task->assigned_user_id = $new;
        }

        foreach (['title', 'description', 'status', 'due_date'] as $field) {
            if (array_key_exists($field, $data)) {
                $task->{$field} = $data[$field];
            }
        }

        $task->save();

        $this->bumpProjectTasksVersion($task->project_id);

        return $task;
    }

    public function delete(int $userId, int $taskId): void
    {
        $task = $this->tasks->findForUserOrFail($userId, $taskId);
        $projectId = $task->project_id;

        $task->delete();

        $this->bumpProjectTasksVersion($projectId);
    }
}
