<?php

namespace App\Observers;

use App\Models\Task;
use App\Notifications\TaskAssignedNotification;
use App\Notifications\TaskUpdatedNotification;
use Illuminate\Support\Facades\Log;

class TaskObserver
{
    public function created(Task $task): void
    {
        $this->notifyOnAssignmentChange($task, isCreate: true);
    }

    public function updated(Task $task): void
    {
        $this->notifyOnAssignmentChange($task, isCreate: false);

        // if anything important changed, notify assignee
        $important = ['title', 'description', 'status', 'due_date'];

        foreach ($important as $field) {
            if ($task->wasChanged($field)) {
                $user = $this->resolveAssignee($task);
                if ($user) {
                    $user->notify(new TaskUpdatedNotification($task));
                }
                break;
            }
        }
    }

    private function notifyOnAssignmentChange(Task $task, bool $isCreate): void
    {
        $changedAssigned = $isCreate ? !is_null($task->assigned_user_id) : $task->wasChanged('assigned_user_id');
        $changedAssignee = $isCreate ? !is_null($task->assignee_id) : $task->wasChanged('assignee_id');

        if (!($changedAssigned || $changedAssignee)) {
            return;
        }

        // keep both columns consistent when possible
        if ($task->assignee_id && $task->assigned_user_id !== $task->assignee_id) {
            $task->assigned_user_id = $task->assignee_id;
            $task->saveQuietly();
        } elseif ($task->assigned_user_id && $task->assignee_id !== $task->assigned_user_id) {
            $task->assignee_id = $task->assigned_user_id;
            $task->saveQuietly();
        }

        $user = $this->resolveAssignee($task);
        if ($user) {
            $user->notify(new TaskAssignedNotification($task));
            return;
        }

        // warning expected by unit test when assigned_user_id is invalid (e.g., 999999)
        if (!is_null($task->assigned_user_id)) {
            Log::warning('Assigned user relation missing for task', [
                'task_id' => $task->id,
                'assigned_user_id' => $task->assigned_user_id,
            ]);
        }
    }

    private function resolveAssignee(Task $task)
    {
        // prefer FK relation if present
        if (!is_null($task->assignee_id)) {
            return $task->assignee()->first();
        }

        // fallback for unit tests that only use assigned_user_id
        if (!is_null($task->assigned_user_id)) {
            return $task->assignedUser()->first();
        }

        return null;
    }
}
