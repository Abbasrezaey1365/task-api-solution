<?php

namespace App\Repositories;

use App\Models\Project;
use App\Models\Task;
use Illuminate\Pagination\LengthAwarePaginator;

class TaskRepository
{
    public function paginateForUserProject(int $userId, int $projectId, array $filters, int $perPage = 50): LengthAwarePaginator
    {
        $project = Project::query()
            ->where('id', $projectId)
            ->where('user_id', $userId)
            ->firstOrFail();

        $q = Task::query()->where('project_id', $project->id);

        if (!empty($filters['status'])) {
            $q->where('status', $filters['status']);
        }

        return $q->orderByDesc('id')->paginate($perPage);
    }

    public function create(int $projectId, array $data): Task
    {
        return Task::query()->create([
            'project_id' => $projectId,

            // nullable in DB (tests), but accept if provided
            'user_id' => $data['user_id'] ?? null,

            'assignee_id' => $data['assignee_id'] ?? null,
            'assigned_user_id' => $data['assigned_user_id'] ?? null,

            'title' => $data['title'],
            'description' => $data['description'] ?? null,
            'status' => $data['status'] ?? 'todo',
            'due_date' => $data['due_date'] ?? null,
        ]);
    }

    public function findForUserOrFail(int $userId, int $taskId): Task
    {
        $task = Task::query()->findOrFail($taskId);

        $project = Project::query()
            ->where('id', $task->project_id)
            ->where('user_id', $userId)
            ->firstOrFail();

        return $task;
    }

    public function assertTaskVisibleToUser(int $userId, int $taskId): void
    {
        $task = Task::query()->findOrFail($taskId);

        Project::query()
            ->where('id', $task->project_id)
            ->where('user_id', $userId)
            ->firstOrFail();
    }
}
